#define _OJ_ONLINE_JUDGE_
#define	min3(x,y,z)	(min(min(x,y),z))
#define	max3(x,y,z)	(max(max(x,y),z))
#define	min4(x,y,u,v)	(min(min(x,y),min(u,v)))
#define	max4(x,y,u,v)	(max(max(x,y),max(u,v)))
#define	ALL(x)  (x.begin()), (x.end())
#define	INS(x)  inserter(x, x.begin())
#define	INF	0x3f3f3f3f
#define	MOD	1000000007
#define	PI	3.1415927
#define	EPS	1e-10


#include "bits/stdc++.h"
#include <iomanip>
using namespace std;


typedef long long Long;
typedef pair<int, int> ii;
typedef tuple<int, int, int> iii;
typedef vector<int> vi;
typedef vector<ii>  vii;
#define  xx    first
#define  yy    second

int kase, ans[100005];



int QuickPower(int x,int y,int p){
    int ans = 1;
    while(y){
        if (y & 1){
            ans = ans * x % p;
        }
        x = x * x % p;
        y >>= 1;
    }
    return ans;
}


bool check(int x){
    vector<int> digit;
    int t = x, cnt = 0;
    while(t){
        cnt++;
        digit.push_back(t % 10);
        t /= 10;
    }
    int y = 0;
    for (int i = 0; i < digit.size(); i++){
        y += QuickPower(digit[i], cnt, MOD);
    }
    // cout << "位数:" << cnt << endl;
    return x == y;
}


int main(){ 
    
    int lo, hi;
    while (cin >> lo >> hi){
        for (int i = lo; i <= hi; i++){
            if(check(i)){
                cout << i << endl;
            }
        }
    }

    return 0;
}

//https://witacm.com/problem.php?pid=1461