#define _OJ_ONLINE_JUDGE_
#define	min3(x,y,z)	(min(min(x,y),z))
#define	max3(x,y,z)	(max(max(x,y),z))
#define	min4(x,y,u,v)	(min(min(x,y),min(u,v)))
#define	max4(x,y,u,v)	(max(max(x,y),max(u,v)))
#define	ALL(x)  (x.begin()), (x.end())
#define	INS(x)  inserter(x, x.begin())
#define	INF	0x3f3f3f3f
#define	MOD	1000000007
#define	PI	3.1415927
#define	EPS	1e-10


#include "bits/stdc++.h"
#include <iomanip>
using namespace std;


typedef long long Long;
typedef pair<int, int> ii;
typedef tuple<int, int, int> iii;
typedef vector<int> vi;
typedef vector<ii>  vii;
#define  xx    first
#define  yy    second


int arr[30];
int n, k, kase, ans, dis;

void dfs(int idx,int k,int s){
    if (idx == n){
        if(abs(s - k) < dis){
            dis = abs(s - k);
            ans = s;
        }
        return;
    }
    dfs(idx+1, k, s + arr[idx]);
    dfs(idx+1, k, s - arr[idx]);
}


int main(){ 
   
    cin >> kase;
    while (kase--){
        cin >> n >> k;
        for (int i = 0; i < n; i++){
            cin >> arr[i];
        }
        //其实本题无需存储ans,
        //只需dis即可        
        ans = dis = INT_MAX;
        dfs(1, k, arr[0]);
        cout << dis << endl;
    }
    return 0;
}

//https://witacm.com/problem.php?pid=1468