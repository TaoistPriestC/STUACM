#define _OJ_ONLINE_JUDGE_
#define	min3(x,y,z)	(min(min(x,y),z))
#define	max3(x,y,z)	(max(max(x,y),z))
#define	min4(x,y,u,v)	(min(min(x,y),min(u,v)))
#define	max4(x,y,u,v)	(max(max(x,y),max(u,v)))
#define	ALL(x)  (x.begin()), (x.end())
#define	INS(x)  inserter(x, x.begin())
#define	INF	0x3f3f3f3f
#define	MOD	1000000007
#define	PI	3.1415927
#define	EPS	1e-10


#include "bits/stdc++.h"
#include <iomanip>
using namespace std;


typedef long long Long;
typedef pair<int, int> ii;
typedef tuple<int, int, int> iii;
typedef vector<int> vi;
typedef vector<ii>  vii;
#define  xx    first
#define  yy    second



int n, m, kase, ans;
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};

char maze[1005][1005];
bool vist[1005][1005];

typedef struct Node{
    int x, y, s;
} Node;
bool check(int x,int y){
    return x >= 1 && x <= n && y >= 1 && y <= m  && !vist[x][y] && maze[x][y] != '*';
}

int BFS(int x,int y){
    queue<Node> que;
    que.push({x, y, 0});
    vist[x][y] = 1;
    int ix, iy, nx, ny, ns;
    while(!que.empty()){
        Node t = que.front();
        ix = t.x;
        iy = t.y;
        que.pop();
        for (int i = 0; i < 4; i++){
            nx = ix + dx[i];
            ny = iy + dy[i];
            if(check(nx,ny)){
                vist[nx][ny] = true;
                ns = t.s + 1;
                if(maze[nx][ny]=='#'){
                    return ns;
                }else{
                    que.push({nx, ny, ns});
                }
            }
        }
    }
    return -1;
}


int main(){ 
    #ifdef _OJ_ONLINE_JUDGE_
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
    #endif
    #ifndef  _OJ_ONLINE_JUDGE_
    std::ios::sync_with_stdio(false);
    //ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);//
    #endif

 
    while (cin >> n >> m){
        memset(vist, 0, sizeof(vist));
        for (int i = 1; i <= n; i++){
            for (int j = 1; j <= m; j++){
                cin >> maze[i][j];
            }
        }
        // for (int i = 1; i <= n; i++){
        //     for (int j = 1; j <= m; j++){
        //         cout << maze[i][j];
        //     }
        //     cout << endl;
        // }

        cout << BFS(1, 1) << endl;
    }

    return 0;
}

//https://witacm.com/problem.php?pid=1464