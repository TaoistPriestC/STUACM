#define _OJ_ONLINE_JUDGE_
#define	min3(x,y,z)	(min(min(x,y),z))
#define	max3(x,y,z)	(max(max(x,y),z))
#define	min4(x,y,u,v)	(min(min(x,y),min(u,v)))
#define	max4(x,y,u,v)	(max(max(x,y),max(u,v)))
#define	ALL(x)  (x.begin()), (x.end())
#define	INS(x)  inserter(x, x.begin())
#define	INF	0x3f3f3f3f
#define	MOD	1000000007
#define	PI	3.1415927
#define	EPS	1e-10


#include "bits/stdc++.h"
#include <iomanip>
using namespace std;


typedef long long Long;
typedef pair<int, int> ii;
typedef tuple<int, int, int> iii;
typedef vector<int> vi;
typedef vector<ii>  vii;
#define  xx    first
#define  yy    second

char ss[100005],tt[100005];
Long merge(char ss[],int lo,int md,int hi){
    Long ans = 0;
    int i = lo, j = md + 1, k = 0;
    while (i <= md && j <= hi){
        if(ss[i] <= ss[j]){
            tt[k++] = ss[i++];
        }else{ //逆序
            tt[k++] = ss[j++];
            ans += (md - i + 1);
        }
    }
    while (i <= md)tt[k++] = ss[i++];
    while (j <= hi)tt[k++] = ss[j++];
    for (int i = 0; i < k; i++){
        ss[lo + i] = tt[i];
    }
    return ans;
}

Long mergeSort(char ss[],int lo,int hi){
    Long lp = 0, mp = 0, rp = 0;
    if(lo < hi){
        int md = lo + (hi - lo) / 2;
        lp = mergeSort(ss, lo, md);
        rp = mergeSort(ss, md + 1, hi);
        mp = merge(ss, lo, md, hi);
    }
    return lp + mp + rp;
}



int kase;
int main(){ 

    cin >> kase;
    while(kase--){
        cin >> ss;
        cout << mergeSort(ss, 0, strlen(ss) - 1) << endl;
    }


    return 0;
}

//https://witacm.com/problem.php?pid=1467