#define	ALL(x)  (x.begin()), (x.end())
#define	INS(x)  inserter(x, x.begin())
#define	INF	0x3f3f3f3f
#define	MOD	1000000007
#define	PI	3.1415927
#define	EPS	1e-10


#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

const int n = 2021;
const int MAXN = 2025;

int mat[MAXN][MAXN], dist[MAXN], vist[MAXN];

int gcd(int a,int b){
    return b == 0 ? a : gcd(b, a % b);
}

int lcm(int a,int b){
    return a / gcd(a, b) * b;
}

int dijstra(int src,int dst){
    memset(vist, 0, sizeof(vist));
    memset(dist, 0x3f, sizeof(dist));
    dist[src] = 0;
    for (int i = 1; i < dst; i++){
        int t = -1;
        for (int j = 1; j <= dst; j++){
            if (!vist[j] && (t == -1 || dist[t] > dist[j])){
                t = j;
            }
        }
        vist[t] = 1;
        for (int j = 1; j <= dst; j++){
            if(dist[t] + mat[t][j] < dist[j]){
                dist[j] = dist[t] + mat[t][j];
            }
        }
    }
    return (dist[dst] == INF ? -1 : dist[dst]);
}


//答案：10266837
int main(){ 
    memset(mat, 0x3f, sizeof(mat));
    for (int i = 1; i <= n; i++){
        for (int j = max(1, i - 21); j < min(n, i + 21); j++){
            mat[i][j] = mat[j][i] = lcm(i, j);
        }
    }
    //测试一下建图的结果是否正确
    // cout << mat[1][23] << endl;
    // cout << mat[3][24] << endl;
    // cout << mat[15][25] << endl;

    cout << dijstra(1, 2021) << endl;

    return 0;
}