#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

typedef long long Long;

Long n;
int main(){
    cin >> n;
    n /= 1000;  //去掉末尾代表微秒的三位数
    n %= 86400; //由于不在乎具体是第几天,因此的取模每天的秒数 24*60*60
    int h = n / 3600;
    n %= 3600;
    int m = n / 60;
    int s = n % 60;
    printf("%02d:%02d:%02d\n", h, m, s);
    return 0;
}

//另外一种做法是考虑平年、闰年,按天进行模拟,但是显然不如上面这种