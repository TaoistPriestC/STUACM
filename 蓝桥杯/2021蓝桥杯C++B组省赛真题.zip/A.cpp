#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

// 答案:67108864
int main(){ 
   
    cout << (256 * 1024 * 1024 / 4) << endl;
    return 0;
}