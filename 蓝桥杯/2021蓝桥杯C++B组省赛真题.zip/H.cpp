#define _OJ_ONLINE_JUDGE_
#define	min3(x,y,z)	(min(min(x,y),z))
#define	max3(x,y,z)	(max(max(x,y),z))
#define	min4(x,y,u,v)	(min(min(x,y),min(u,v)))
#define	max4(x,y,u,v)	(max(max(x,y),max(u,v)))
#define	ALL(x)  (x.begin()), (x.end())
#define	INS(x)  inserter(x, x.begin())
#define	INF	0x3f3f3f3f
#define	MOD	1000000007
#define	PI	3.1415927
#define	EPS	1e-10


#include "bits/stdc++.h"
#include <iomanip>
using namespace std;


typedef long long Long;
typedef unsigned long long ULL;
typedef pair<int, int> ii;
typedef tuple<int, int, int> iii;
typedef vector<int> vi;
typedef vector<ii>  vii;
#define  xx    first
#define  yy    second

Long n;

Long Comb(int a,int b){
    Long ans = 1;
    for (int i = a, j = 1; j <= b; i--, j++){
        ans = ans * i / j;
        if(ans > n) {
            return ans;
        }
    }
    return ans;
}


Long check(int k){
    //C(n,k) 二分寻找满足条件的最小n
    int lo = 2 * k, hi = n;
    while(lo < hi){
        int md = (lo + hi) >> 1;
        if (Comb(md, k) >= n){
            hi = md;
        }else{
            lo = md + 1;
        }
    }
    return Comb(hi, k) != n ? (-1) : (hi * (hi + 1) / 2 + k + 1);
}


int main(){ 
    #ifdef _OJ_ONLINE_JUDGE_
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
    #endif
    #ifndef  _OJ_ONLINE_JUDGE_             
    std::ios::sync_with_stdio(false);
    //ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);//
    #endif

    Long tmp;
    while(cin >> n){
        if(n==1){
            cout<<1<<endl;
            continue;
        }
        // 组合数 C 34 取 17 已经大过题设的最大输入了
        /* 
            组合数和杨辉三角：第i行第j列的数都是组合数C(i, j) （i，j从0开始）
            C(n, 1) = n --> 对应从左向右看斜着的第二列！ ---> 一定有解
            由于杨辉三角左右对称（C(a, b) == C(a, a-b)），又由于找第一次出现，因此一定在左边，右边可以直接删掉！

                            1  ---> C(0, 0)
                          1 
                        1   2  ---> C(2, 1)
                      1   3                      ---> C(2n, n)
                    1   4   6  ---> C(4, 2)
                  1   5   10
                1   6   15  20 ---> C(6, 3)

            性质：
            1. 每一斜行从上到下递增;
            2. 每一横行从中间到两边依次递减;
            因此我们直接从中间对称轴倒序二分找起即可!
        */
       
        //对斜行进行二分
        for (int k = 16;  ; k--){
            if ((tmp = check(k)) != -1){
                cout << tmp << endl;
                break;
            }
        }
    }
    return 0;
}