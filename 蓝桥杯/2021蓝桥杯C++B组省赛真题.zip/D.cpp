#include "bits/stdc++.h"
#include <iomanip>
using namespace std;


typedef long long Long;
typedef unsigned long long ULL;

//本题实际是一个因数分解问题，要求n = a * b * c，问你共有几种分解方法;


Long n;
int main(){
    cin >> n;
    vector<Long> div;
    for (Long i = 1; i * i <= n; i ++ ){
        if (n % i == 0){
            div.push_back(i);
            if (n / i != i) {
                div.push_back(n / i);
            }
        }
    }

    int ans = 0;
    for (auto a: div){
        for (auto b: div){
            for (auto c: div){
                if (a * b * c == n)
                    ans ++ ;
            }
        }
    }
    cout << ans << endl;

    return 0;
}
