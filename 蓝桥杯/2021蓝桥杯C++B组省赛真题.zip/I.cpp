#define _OJ_ONLINE_JUDGE_
#define	min3(x,y,z)	(min(min(x,y),z))
#define	max3(x,y,z)	(max(max(x,y),z))
#define	min4(x,y,u,v)	(min(min(x,y),min(u,v)))
#define	max4(x,y,u,v)	(max(max(x,y),max(u,v)))
#define	ALL(x)  (x.begin()), (x.end())
#define	INS(x)  inserter(x, x.begin())
#define	INF	0x3f3f3f3f
#define	MOD	1000000007
#define	PI	3.1415927
#define	EPS	1e-10


#include "bits/stdc++.h"
#include <iomanip>

using namespace std;

typedef long long Long;
typedef unsigned long long ULL;
typedef pair<int, int> ii;
typedef tuple<int, int, int> iii;
typedef vector<int> vi;
typedef vector<ii>  vii;
#define  xx    first
#define  yy    second

const int N = 100010;

int n, m;
ii stk[N];
int ans[N];

int main(){
    // #ifdef _OJ_ONLINE_JUDGE_
    // freopen("test.in","r",stdin);
    // freopen("test.out","w",stdout);
    // #endif
    // #ifndef  _OJ_ONLINE_JUDGE_
    // std::ios::sync_with_stdio(false);
    // //ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);//
    // #endif

    scanf("%d%d", &n, &m);
    int top = 0;
    while (m --) {
        int p, q;
        scanf("%d%d", &p, &q);
        if (p == 0){
            while (top && stk[top].xx == 0)
                q = max(q, stk[top--].yy);
            while (top >= 2 && stk[top - 1].yy <= q) 
                top -= 2;
            stk[++top] = {0, q};
        }else if (top){
            while (top && stk[top].xx == 1)
                q = min(q, stk[top--].yy);
            while (top >= 2 && stk[top - 1].yy >= q) 
                top -= 2;
            stk[++top] = {1, q};
        }
    }
    
    int k = n, lo = 1, hi = n;
    for (int i = 1; i <= top; i++){
        if (stk[i].xx == 0){
            while (hi > stk[i].yy && lo <= hi) 
                ans[hi--] = k--;
        }else{
            while (lo < stk[i].yy && lo <= hi) 
                ans[lo++] = k--;
        }
        if (lo > hi) break;
    }

    if (top % 2){ 
        while (lo <= hi) ans[lo ++ ] = k -- ;
    }else{
        while (lo <= hi) ans[hi -- ] = k --;
    } 

    for (int i = 1; i <= n; i ++ ){
        printf("%d ", ans[i]);
    }
    return 0;
}
