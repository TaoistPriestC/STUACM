#include "bits/stdc++.h"
#include <iomanip>

using namespace std;

typedef long long Long;
typedef unsigned long long ULL;

const int N = 5005, MOD = 1e9 + 7;

int n;
char str[N];
Long dp[N][N];

Long DP(){
    // dp[i][j],满足“序列第i个括号,左括号比右括号多j个”条件的合法序列个数
    // 此处认为左括号大于或等于右括号个数的序列都是合法的
    memset(dp, 0, sizeof(dp));
    dp[0][0] = 1;
    for (int i = 1; i <= n; i ++ )
        if (str[i] == '('){
            for (int j = 1; j <= n; j ++ )
                dp[i][j] = dp[i - 1][j - 1];
        }else{
            dp[i][0] = (dp[i - 1][0] + dp[i - 1][1]) % MOD;
            for (int j = 1; j <= n; j ++){
                // dp[i][j - 1] = dp[i-1][j] + dp[i-1][j-1] + ... +dp[i-1][0]
                dp[i][j] = (dp[i - 1][j + 1] + dp[i][j - 1]) % MOD;
            }
        }
    for (int i = 0; i <= n; i ++ )
        if (dp[n][i]){
            return dp[n][i];
        }
    return - 1;
}

int main(){
    scanf("%s", str + 1);
    n = strlen(str + 1);
    Long l = DP();
    reverse(str + 1, str + n + 1);
    for (int i = 1; i <= n; i ++ )  
        if (str[i] == '(') str[i] = ')';
        else str[i] = '(';
    Long r = DP();
    printf("%lld\n", l * r % MOD);
    return 0;
} 
