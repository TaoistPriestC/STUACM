



### G：解法分析

采用暴力的回溯算法能够通过大部分样例，但会 `TLE`，本题其实是背包问题的变种，物品可以放左边也可以放在右边，可以等价为物品的 重量可正可负，也因为这个特点，故其无法通过从后往前遍历来优化为空间开销，而且对于负数的情况还要增加一个偏移量以防越界。除此之外，母函数、位运算也能在限定时间之内解出此题。



#### G：暴力回溯

```c++
#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

const int MAXN = 205;

int n;
int arr[MAXN], vis[MAXN], eqt[2];//eqt[0]、eqt[1]代表天平左右两边
set<int> t;

void dfs(int idx){
    for (int i = idx; i < n; i++){
        if(!vis[i]){
            for (int j = 0; j < 2; j++){
                vis[i] = 1;
                eqt[j] += arr[i];
                t.insert(abs(eqt[0] - eqt[1]));//左右天平的差值
                dfs(i + 1);
                eqt[j] -= arr[i];
                vis[i] = 0;
            }
        }
    }
}

int main(){   
    while(cin >> n){
        t.clear();
        for (int i = 0; i < n; i++)
            cin >> arr[i];
        dfs(0);
        cout << t.size() << endl;
    }
    
    return 0;
}
```



#### G：动态规划

```c++
#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

int n, m;
const int MAXN = 205;	//砝码个数+
const int MAXM = 200010;//砝码最大重量的两倍+
const int MAXB = 100005;//偏移量+

//若不想使用增加偏移量，可将转移方程改为: 
//dp[i][j]=dp[i-1][j]||dp[i-1][abs(j+w[i])]||f[i-1][abs(j-w[i])]


int arr[MAXN], dp[MAXN][MAXM];


int main(){
    while(cin >> n){
        m = 0;
        for (int i = 1; i <= n; i++){
            cin >> arr[i];
            m += arr[i];
        }
        dp[0][MAXB] = 1;
        for (int i = 1; i <= n; i++){
            for (int j = -m; j <= m; j++){
                dp[i][j + MAXB] = dp[i - 1][j + MAXB];
                if (j - arr[i] >= -m){
                    dp[i][j + MAXB] |= dp[i - 1][j - arr[i] + MAXB];
                }
                if (j + arr[i] <= m){
                    dp[i][j + MAXB] |= dp[i - 1][j + arr[i] + MAXB];
                }
            }
        }
        int ans = 0; 
        for (int i = 1; i <= m; i++){
            if (dp[n][i + MAXB]){
                ans++;
            }
        }
        cout << ans << endl;
    }
    

    return 0;
}
```



#### G：母函数

```c++
#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

const int N = 1050;
const int M = 1000005;

//本题实为HDU1709原题，母函数(生成函数)
int c1[M],c2[M],w[N];

int main(){
    int n;
    scanf("%d",&n);
    int maxl = 0;
    for(int i = 0;i < n;i++) {
        scanf("%d",&w[i]);
        maxl += w[i];
    }
    c1[0] = c1[w[0]] = 1;
    for (int i = 1; i < n; i++){
        for (int j = 0; j <= maxl; j++){
            for (int k = 0; k <= w[i]; k += w[i]){
                c2[j + k] += c1[j];
                c2[abs(j - k)] += c1[j];
            }
        }
        for (int j = 0; j <= maxl; j++){
            c1[j] = c2[j];
            c2[j] = 0;
        }
    }
    int cnt = 0;
    for (int i = 1; i <= maxl; i++){
        if(c1[i])cnt++;
    }
    cout << cnt;
}

```



#### G：位运算

```c++
#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

const int N = 105, M = 100005;

int arr[N], n;

bitset<M> S;

int main(){
    scanf("%d", &n);
    for(int i = 0; i < n; i ++ ){
        scanf("%d", &arr[i]);
    }
    S[0] = 1;
    for(int i = 0; i < n; i ++ ){
        S |= S << arr[i];
    }
    for(int i = 0; i < n; i ++ ){
        S |= S >> arr[i];
    }
    cout << S.count() - 1 << endl;
    return 0;
}
```





### H：解法分析

```c++
#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

Long n, tmp;
Long Comb(int a,int b){
    Long ans = 1;
    for (int i = a, j = 1; j <= b; i--, j++){
        ans = ans * i / j;
        if(ans > n) {
            return ans;
        }
    }
    return ans;
}

Long check(int k){
    //C(n,k) 二分寻找满足条件的最小n
    int lo = 2 * k, hi = n;
    while(lo < hi){
        int md = (lo + hi) >> 1;
        if (Comb(md, k) >= n){
            hi = md;
        }else{
            lo = md + 1;
        }
    }
    return Comb(hi, k) != n ? (-1) : (hi * (hi + 1) / 2 + k + 1);
}

int main(){ 

    while(cin >> n){
        if(n==1){
            cout<<1<<endl;
            continue;
        }
        /* 
          	组合数 C 34 取 17 已经大过题设的最大输入了，故在 k:0~16 必有答案
            组合数和杨辉三角：第i行第j列的数都是组合数 C(i, j) （i，j从0开始）
            C(n, 1) = n --> 对应从左向右看斜着的第二列！
            由于杨辉三角左右对称（C(a, b) == C(a, a-b)），
            又由于找第一次出现，因此一定在左边，右边可以直接删掉！

                            1  ---> C(0, 0)
                          1 
                        1   2  ---> C(2, 1)
                      1   3                      ---> C(2n, n)
                    1   4   6  ---> C(4, 2)
                  1   5   10
                1   6   15  20 ---> C(6, 3)

            性质：
            1. 每一斜行从上到下递增;
            2. 每一横行从中间到两边依次递减;
            因此我们直接从中间对称轴倒序二分找起即可!
        */
       
        //对斜行进行二分
        for (int k = 16;  ; k--){
            if ((tmp = check(k)) != -1){
                cout << tmp << endl;
                break;
            }
        }
    }
    return 0;
}
```





### I : 解法分析

长区间会覆盖短区间，因为使用数组模拟单调栈，按照题设的关系令长区间吞并短区间，最终再按照栈中顺序的输出答案序列。

```c++
#include "bits/stdc++.h"
#include <iomanip>

using namespace std;

typedef long long Long;
typedef unsigned long long ULL;
typedef pair<int, int> ii;

#define  xx    first
#define  yy    second

const int N = 100010;

ii stk[N];
int n, m,ans[N];

int main(){
   
    scanf("%d%d", &n, &m);
    int top = 0;
    while (m --) {
        int p, q;
        scanf("%d%d", &p, &q);
        if (p == 0){
            while (top && stk[top].xx == 0)
                q = max(q, stk[top--].yy);
            while (top >= 2 && stk[top - 1].yy <= q) 
                top -= 2;
            stk[++top] = {0, q};
        }else if (top){
            while (top && stk[top].xx == 1)
                q = min(q, stk[top--].yy);
            while (top >= 2 && stk[top - 1].yy >= q) 
                top -= 2;
            stk[++top] = {1, q};
        }
    }
    
    int k = n, lo = 1, hi = n;
    for (int i = 1; i <= top; i++){
        if (stk[i].xx == 0){
            while (hi > stk[i].yy && lo <= hi) 
                ans[hi--] = k--;
        }else{
            while (lo < stk[i].yy && lo <= hi) 
                ans[lo++] = k--;
        }
        if (lo > hi) break;
    }

    if (top % 2){ 
        while (lo <= hi) ans[lo ++ ] = k -- ;
    }else{
        while (lo <= hi) ans[hi -- ] = k --;
    } 

    for (int i = 1; i <= n; i ++ ){
        printf("%d ", ans[i]);
    }
    return 0;
}

```

