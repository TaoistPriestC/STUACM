#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

const int MAXN = 200000;

int n;
struct Line{
    double k, b;
    //重载运算符用以sort排序
    bool operator< (const Line& other) const{
        if (k != other.k) return k < other.k;
        return b < other.b;
    }
}lines[MAXN];


//答案：40257
int main(){
    for (int x1 = 0; x1 < 20; x1 ++ )
        for (int y1 = 0; y1 < 21; y1 ++ )
            for (int x2 = 0; x2 < 20; x2 ++ )
                for (int y2 = 0; y2 < 21; y2 ++ )
                    if (x1 != x2){
                        double k = (double)(y2 - y1) / (x2 - x1);
                        double b = y1 - k * x1;
                        lines[n ++ ] = {k, b};
                    }

    sort(lines, lines + n); //想要找出不同元素,只需要的排序再比较相邻元素即可;
    int ans = 1;
    for (int i = 1; i < n; i ++ )
        //如果比较的时候，没有设置精度会得到一个错误答案
        if (fabs(lines[i].k - lines[i - 1].k) > 1e-8 || fabs(lines[i].b - lines[i - 1].b) > 1e-8)
            ans ++ ;
    //最后需要再加上特殊判定的垂线
    cout << ans + 20 << endl;

    return 0;
}
