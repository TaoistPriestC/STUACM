#include "bits/stdc++.h"
#include <iomanip>
using namespace std;

int s[10];//用于存储每个数字的个数

bool check(int x){
    int t;
    while(x){
        s[ t = x % 10]--;
        x /= 10;
        if(s[t] < 0){
            return false;
        }
    }
    return true;
}

//答案:3181
int main(){ 
    for (int i = 0; i < 10; i++)
        s[i] = 2021;
    for (int i = 0 ;   ; i++ ){
        if(!check(i)){
            cout << i - 1 << endl;
            break;
        }
    }
    
    return 0;
}